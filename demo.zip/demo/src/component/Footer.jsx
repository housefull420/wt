import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>jeyachandran j</p>
    </footer>
  );
};

export default Footer;
